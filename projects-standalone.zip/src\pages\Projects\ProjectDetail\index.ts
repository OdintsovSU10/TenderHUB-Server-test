export { default } from './ProjectDetail';
